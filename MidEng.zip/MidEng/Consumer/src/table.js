document.addEventListener("DOMContentLoaded", function () {

    fetch("http://localhost:8080/api/warehouse/json")
        .then(response => response.json())
        .then(data => {

            const products = data.productData.products;

            const table = document.getElementById("warehouse-table");

            const headers = Object.keys(products[0]);
            const headerRow = table.insertRow();
            headers.forEach(headerText => {
                const header = document.createElement("th");
                header.textContent = headerText;
                headerRow.appendChild(header);
            });

            products.forEach(product => {
                const row = table.insertRow();
                headers.forEach(headerText => {
                    const cell = row.insertCell();
                    cell.textContent = product[headerText];
                });
            });
        })
        .catch(error => {
            console.error("Error fetching data:", error);
        });
});
