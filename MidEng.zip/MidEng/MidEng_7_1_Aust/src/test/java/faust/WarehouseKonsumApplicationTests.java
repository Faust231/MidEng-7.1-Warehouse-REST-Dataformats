package faust;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WarehouseKonsumApplicationTests {

	@Test
	void contextLoads() {
	}

}
