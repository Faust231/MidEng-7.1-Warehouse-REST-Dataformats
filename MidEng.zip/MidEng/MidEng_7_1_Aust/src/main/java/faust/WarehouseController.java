package faust;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.http.MediaType;

@RestController
public class WarehouseController {

    @RequestMapping("/")
    public String warehouseMain() {
        String mainPage = "This is the warehouse application! (DEZSYS_WAREHOUSE_REST) <br/><br/>" +
                "<a href='http://localhost:8080/api/warehouse/json'>JSON</a><br/>" +
                "<a href='http://localhost:8080/api/warehouse/xml'>XML</a><br/>" +
                "<a href='http://localhost:8081/'>Consumer</a><br/>";
        return mainPage;
    }


    @GetMapping(value = "/api/warehouse/json", produces = "application/json")
    public String getWarehouseDataJSON() {
        WarehouseData warehouseData = new WarehouseData();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = "error";
        try {
            json = objectMapper.writeValueAsString(warehouseData);
            System.out.println(json);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return json;
    }

    @RequestMapping(value="/api/warehouse/xml", produces = MediaType.APPLICATION_XML_VALUE)
    public WarehouseData getWarehouseDataXML() {
        WarehouseData warehouseData = new WarehouseData();
        return warehouseData;
    }
}
