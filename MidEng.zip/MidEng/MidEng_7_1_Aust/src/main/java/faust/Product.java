package faust;

import java.util.Random;
import com.fasterxml.jackson.annotation.JsonInclude;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class Product {
    private String productID;
    private String productName;
    private String productCategory;
    private int productQuantity;
    private String productUnit;

    private static final String[] UNIQUE_NAMES = {"Pineapple", "Quinoa", "Tofu", "Mussels", "Gouda cheese", "Cabbage", "Sushi", "Pistachios", "Guacamole", "Croissant"};
    private static final String[] UNIQUE_CATEGORIES = {"Drink", "Food"};

    public Product() {
        Random random = new Random();
        this.productID = String.valueOf(random.nextInt(899)+100)+"-"+String.valueOf(random.nextInt(89999999)+10000000);
        this.productName = UNIQUE_NAMES[random.nextInt(UNIQUE_NAMES.length)];
        this.productCategory = UNIQUE_CATEGORIES[random.nextInt(UNIQUE_CATEGORIES.length)];
        this.productQuantity = random.nextInt(4001 - 100) + 100;
        if(productCategory.equals("Drink")){
            this.productUnit = "1 L";
        } else {
            this.productUnit = "1 KG";
        }

    }

    public String getProductID() {
        return productID;
    }

    public String getProductName() {
        return productName;
    }

    public String getProductCategory() {
        return productCategory;
    }

    public int getProductQuantity() {
        return productQuantity;
    }

    public String getProductUnit() {
        return productUnit;
    }
}
