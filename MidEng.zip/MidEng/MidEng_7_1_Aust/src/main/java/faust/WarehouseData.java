package faust;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.text.SimpleDateFormat;
import java.util.Date;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class WarehouseData {
    private String warehouseID;
    private String warehouseName;
    private String warehouseAddress;
    private String warehousePostalCode ;
    private String warehouseCity;
    private String warehouseCountry;
    private String timestamp;
    private ProductData productData;

    public WarehouseData() {
        warehouseID = "001";
        warehouseName = "Linz Bahnhof";
        warehouseAddress = "Bahnhofsstrasse 27/9";
        warehousePostalCode = "Linz";
        warehouseCity = "Linz";
        warehouseCountry = "Austria";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        this.timestamp = dateFormat.format(new Date());
        this.productData = new ProductData(4);
    }


    public String getWarehouseID() {
        return warehouseID;
    }

    public String getWarehouseName() {
        return warehouseName;
    }

    public String getWarehouseAddress() {
        return warehouseAddress;
    }

    public String getWarehousePostalCode() {
        return warehousePostalCode;
    }

    public String getWarehouseCity() {
        return warehouseCity;
    }

    public String getWarehouseCountry() {
        return warehouseCountry;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public ProductData getProductData() {
        return productData;
    }
}