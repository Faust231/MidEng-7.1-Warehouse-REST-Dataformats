package faust;

import java.util.List;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonInclude;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductData{
    private List<Product> products;


    public ProductData(int amount) {
        this.products = new ArrayList<>();
        for (int i = 0; i < amount; i++) {
            this.products.add(new Product());
        }
    }
    public List<Product> getProducts() {
        return products;
    }
}